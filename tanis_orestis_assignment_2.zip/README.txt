******* DATABASE SCHEMA CREATION & TABLE POPULATION ********
To create the database schema and the populated table you can:
1) Either execute the sql code located in schema.sql file under /src/main/resources/
2) Or import the trainermvc_trainers.sql dump file located under /src/main/resources/ via MySQL Workbench

******* DB CONNECTION SETTINGS *********
You can change the settings regarding the connection with the database in /src/main/resources/application.properties file

